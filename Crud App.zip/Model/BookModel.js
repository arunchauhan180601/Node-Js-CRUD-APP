const mongoose = require("mongoose");

const bookSchema = new mongoose.Schema(
  {
    BookName: {
      type: String,
      required: true,
    },
    Price: {
      type: Number,
      required: true,
    },
    Author: {
      type: String,
      required: true,
    },
    Language: {
      type: String,
      required: true,
    },
    Quantity: {
      type: Number,
      required: true,
    },
    Image: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const Book = mongoose.model("Book", bookSchema);

module.exports = Book;
