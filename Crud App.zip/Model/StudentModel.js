const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  StudentName: {
    type: String,
    required: true,
    
  },
  RollNo: {
    type: String,
    required: true,
  },
  Class: {
    type: String,
    required: true,
  },
  Gender: {
    type: String,
    required: true,
  },
  Image: {
    type: String,
    required: true,
  }

},{
  timestamps: true,
});

const Student = mongoose.model("Students", studentSchema);

module.exports = Student


