const express = require("express");
const multer = require("multer");
const {
  handleGetAllBooks,
  handleGetForm,
  handleCreateNewBook,
  handleGetWithoutEditForm,
  handleUpdatedBookDetails,
  handleDeleteBook,
} = require("../Controller/BookController");
const restrictToLoggedInUser = require("../MiddleWare/auth");

const router = express.Router();

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./uploads");
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});

const upload = multer({ storage: storage }).single("image");

router.get("/", restrictToLoggedInUser, handleGetAllBooks);

router.get("/addData", handleGetForm);
router.post("/addData", upload, handleCreateNewBook);

router.get("/editData/:id", handleGetWithoutEditForm);
router.post("/editinfo/:id", upload, handleUpdatedBookDetails);

router.get("/deleteData/:id", handleDeleteBook);

module.exports = router;
