const express = require("express");
const { handleGetStudent, handleGetFormForCreate, handleCreateNewStudent, handleDeleteData, handleDataBeforeUpdate, handleStudentDataUpdate } = require("../Controller/StudentController");
const multer  = require('multer');
const restrictToLoggedInUserOnly = require("../Middleware/auth");


const router = express.Router();

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './uploads')
  },
  filename: function (req, file, cb) {
   
    cb(null, file.originalname)
  }
})

const upload = multer({ storage: storage }).single('image');








router.get("/",  handleGetStudent)

router.get("/addData",restrictToLoggedInUserOnly, handleGetFormForCreate);
router.post("/addData",upload, handleCreateNewStudent );

router.get("/editData/:id",  handleDataBeforeUpdate)

router.get("/deleteData/:id", handleDeleteData);
router.post("/editInfo/:id",upload, handleStudentDataUpdate)

module.exports = router;










