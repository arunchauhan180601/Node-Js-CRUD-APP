const express = require("express");
const { handleSignupForm, handleCreateUser, handleLoginForm, handleValidateWithLogin } = require("../Controller/UserController");
const router = express.Router();


router.get("/signup", handleSignupForm);
router.post("/user/signup", handleCreateUser);

router.get("/login", handleLoginForm);
router.post("/user/login", handleValidateWithLogin)

module.exports = router;