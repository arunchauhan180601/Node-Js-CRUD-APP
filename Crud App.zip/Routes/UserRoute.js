const express = require("express");
const {
  handleGetSignupForm,
  handleUserSignup,
  handleGetLoginForm,
  handleUserLogin,
} = require("../Controller/UserController");

const router = express.Router();

router.get("/signup", handleGetSignupForm);
router.post("/user/signup", handleUserSignup);

router.get("/login", handleGetLoginForm);
router.post("/user/login", handleUserLogin);

module.exports = router;
