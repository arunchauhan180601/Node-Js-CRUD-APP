const User = require("../Model/UserModel");
const { v4: uuidv4 } = require('uuid');
const { setUser } = require("../Service/auth");


function handleSignupForm(req, res){
  try {
     return res.render("signup");
     
  } catch (error) {
    console.log(error);
    res.status(500).json({msg: "Internal Server error"});
  }
}

async function handleCreateUser(req, res){
  try {
    const body = req.body;

    if(!body ||
       !body.userName ||
       !body.email ||
       !body.password
    )
     res.status(400).json({msg: "All Fields Are Required"});

     await User.create({
      UserName: body.userName,
      Email: body.email,
      Password: body.password
     })

     res.render("login");

  } catch (error) {
    console.log(error);
    res.status(500).json({msg: "Internal Server error"});
  }
}

function handleLoginForm(req, res){
  try {
     return res.render("login");
     
  } catch (error) {
    console.log(error);
    res.status(500).json({msg: "Internal Server error"});
  }
}

async function handleValidateWithLogin(req, res){
  try {
  

    const user = await User.findOne({Email: req.body.email, Password: req.body.password});
   


    if(!user) {
     return res.render("login", {
      error : "Password or Email Doesn't Match",
   
    })}
 
    // const sessionId = uuidv4();
     let token = setUser(user);
    res.cookie("uid", token);

    return  res.redirect("/");

  } catch (error) {
    console.log(error);
    return res.status(500).json({msg: "Internal Server error"});
  }
}

module.exports = {
  handleSignupForm,
  handleCreateUser,
  handleLoginForm,
  handleValidateWithLogin
}