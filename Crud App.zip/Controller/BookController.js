const Book = require("../Model/BookModel");

async function handleGetAllBooks(req, res) {
  try {
    const Books = await Book.find({});
    return res.render("home", { books: Books });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "Internal Server Error" });
  }
}

async function handleGetForm(req, res) {
  try {
    return res.render("form");
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "Internal Server Error" });
  }
}

async function handleCreateNewBook(req, res) {

  
  try {
    const body = req.body;

    let image = "";
    if (req.file) {
      image = req.file.path;
    }

    if (
      !body ||
      !body.bookName ||
      !body.price ||
      !body.author ||
      !body.language ||
      !body.quantity
    )
      return res.status(400).json({ msg: "All Fields are Required" });

    await Book.create({
      BookName: body.bookName,
      Price: body.price,
      Author: body.author,
      Language: body.language,
      Quantity: body.quantity,
      Image: image,
    });

    return res.redirect("/");
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "Internal Server Error" });
  }
}

async function handleGetWithoutEditForm(req, res) {
  try {
    const id = req.params.id;
    const findBook = await Book.findById(id);

    if (!findBook) {
      return res.status(404).json({ msg: "Book Not Found" });
    }
    res.render("edit", { editData: findBook });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "Internal Server Error"});
  }
}

async function handleUpdatedBookDetails(req, res) {
  try {
    const id = req.params.id;
    const body = req.body;

    if (req.file) {
      const Image = req.file.path;

      await Book.findByIdAndUpdate(id, {
        BookName: body.bookName,
        Price: body.price,
        Author: body.author,
        Language: body.language,
        Quantity: body.quantity,
        Image: Image,
      });
      console.log("Book updated with new image");
      return res.redirect("/");
    } else {
      await Book.findByIdAndUpdate(id, {
        BookName: body.bookName,
        Price: body.price,
        Author: body.author,
        Language: body.language,
        Quantity: body.quantity,
      });

      console.log("Book updated without new image");
      return res.redirect("/");
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "Internal Server Error" });
  }
}

async function handleDeleteBook(req, res) {
  try {
    const id = req.params.id;
    await Book.findByIdAndDelete(id);
    return res.redirect("/");
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "Internal Server Error" });
  }
}

module.exports = {
  handleGetAllBooks,
  handleGetForm,
  handleCreateNewBook,
  handleGetWithoutEditForm,
  handleUpdatedBookDetails,
  handleDeleteBook,
};












