const Student = require("../Model/StudentModel");

async function handleGetStudent(req, res){
   try {
     const students = await Student.find({});
     res.render("Home", {student: students});
   } catch (error) {
     console.log(error);
     res.status(500).json({msg: "Internal Server Error"});

   }
}

async function handleGetFormForCreate(req, res){
  try {
     return res.render("addForm")
  } catch (error) {
    console.log(error);
    res.status(500).json({msg: "Internal Server Error"});
  }
}

async function handleCreateNewStudent(req, res){
  try {
    const body = req.body;
 
    let image = ""
    if(req.file){
      image = req.file.path
    }


    if(!body ||
       !body.studentName ||
       !body.rollNo ||
       !body.class ||
       !body.gender 

    )

    return res.status(400).json({msg: "All Fields Are required!"});

    await Student.create({
       StudentName : body.studentName,
       RollNo: body.rollNo,
       Class: body.class,
       Gender: body.gender,
       Image: image

    })

    return res.redirect("/");

  } catch (error) {
    console.log(error);
    res.status(500).json({msg: "Internal Server Error"});
  }
}

async function handleDeleteData(req, res){
  try {
     const id = req.params.id;
     await Student.findByIdAndDelete(id);
     res.redirect("/");
  } catch (error) {
     console.log(error);
     res.status(500).json({msg: "Internal Server Error"});
    
  }
}

async function handleDataBeforeUpdate(req, res){
  try {
      const id = req.params.id;

      const studentData = await Student.findById(id);
      
      if(!studentData)  return res.status(400).json({msg: `student with id ${id} is not available`});

      res.render("edit", {editData: studentData});

  } catch (error) {
        console.log(error);
     res.status(500).json({msg: "Internal Server Error"});
  }
}

async function handleStudentDataUpdate(req, res){
  try {
    
    const id = req.params.id;
    const body = req.body;

    if(req.file){
      let Image = req.file.path;

      await Student.findByIdAndUpdate(id, {
        StudentName : body.studentName,
        RollNo: body.rollNo,
        Class: body.class,
        Gender: body.gender,
        Image: Image
      })
      console.log("student Updated with Image ");
      return res.redirect("/");
    }

    else{
      await Student.findByIdAndUpdate(id, {
        StudentName : body.studentName,
        RollNo: body.rollNo,
        Class: body.class,
        Gender: body.gender,
      
      })
      console.log("student Updated without Image ");
      return res.redirect("/");
    }
    

   
  } catch (error) {
    console.log(error);
    res.status(500).json({msg: "Internal Server Error"});
  }
}







module.exports = {
  handleGetStudent,
  handleGetFormForCreate,
  handleCreateNewStudent,
  handleDeleteData,
  handleDataBeforeUpdate,
  handleStudentDataUpdate
}