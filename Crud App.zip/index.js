const express = require("express");
const connectDB = require("./connection");
const ejs =  require("ejs");
const path = require("path");
const studentRoutes = require("./Routes/StudentRoutes");
const userRoutes = require("./Routes/UserRoutes");
var cookieParser = require('cookie-parser')

const app = express();

connectDB("mongodb://127.0.0.1:27017/sunaina_node")
  .then(() => {
    console.log("Mongodb Connected");
  })
  .catch((error) => console.log(error));


app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.set("view engine", "ejs");
app.set("views", path.resolve("./views"));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
app.use(cookieParser())


// Routes
app.use(studentRoutes);
app.use(userRoutes)


app.listen(8000, () => {
  console.log("Server Started!");
});
